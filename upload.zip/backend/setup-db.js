const { Client } = require('pg');
const readline = require('readline');
const fs = require('fs');
const path = require('path');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const ask = (query) => new Promise((resolve) => rl.question(query, resolve));

async function main() {
    console.log('====================================================');
    console.log('  SETUP DATABASE POSTGRESQL CBT TKA SDNUP03 (PRAKTIS)');
    console.log('====================================================\n');

    console.log('Script ini akan membantu Anda membuat Database dan file konfigurasi (.env).');
    console.log('Pastikan Anda SUDAH MENGINSTALL aplikasi PostgreSQL di komputer ini.\n');

    const dbUser = 'postgres'; // Default user
    let dbPassword = '';
    let connected = false;
    let attempts = 0;
    const maxAttempts = 3;

    while (!connected && attempts < maxAttempts) {
        if (attempts > 0) {
            console.log(`\n⚠️  PASSWORD SALAH! (Percobaan ${attempts}/${maxAttempts})`);
            console.log('Silakan cek Caps Lock atau ingat kembali password saat instalasi.\n');
        }

        console.log('🔑 TAHAP KEAMANAN:');
        console.log('Silakan ketik manual password PostgreSQL Anda.');
        const dbPasswordInput = await ask('👉 Masukkan Password: ');
        dbPassword = dbPasswordInput.trim();

        const client = new Client({
            user: dbUser,
            host: 'localhost',
            database: 'postgres',
            password: dbPassword,
            port: 5432,
        });

        try {
            console.log('\n⏳ Mencoba terhubung ke PostgreSQL...');
            await client.connect();
            console.log('✅ BERHASIL TERHUBUNG!');
            connected = true;

            // Check if database cbt_tka already exists
            const dbExist = await client.query("SELECT 1 FROM pg_database WHERE datname = 'cbt_tka'");

            if (dbExist.rows.length === 0) {
                console.log('⏳ Menciptakan Database baru: "cbt_tka"...');
                await client.query('CREATE DATABASE cbt_tka');
                console.log('✅ Database "cbt_tka" BERHASIL diciptakan!');
            } else {
                console.log('ℹ️ Informasi: Database "cbt_tka" sudah tersedia di PostgreSQL.');
            }

            // Creating .env file
            const envContent = `DB_USER=${dbUser}\nDB_PASSWORD=${dbPassword}\nDB_HOST=localhost\nDB_PORT=5432\nDB_NAME=cbt_tka\nJWT_SECRET=cbt-tka-secret-key-2026\nPORT=3001\n`;
            const envPath = path.join(__dirname, '.env');

            fs.writeFileSync(envPath, envContent);
            console.log(`✅ File konfigurasi AKTIF dibuat di: backend/.env`);

            console.log('\n====================================================');
            console.log('📊 RINGKASAN KONFIGURASI:');
            console.log(`   - Database : cbt_tka`);
            console.log(`   - User     : ${dbUser}`);
            console.log(`   - Port API : 3001`);
            console.log('====================================================');

            await client.end().catch(() => { });

        } catch (err) {
            attempts++;
            if (attempts >= maxAttempts) {
                console.error('\n❌ GAGAL TOTAL: Anda telah salah memasukkan password sebanyak 3 kali.');
                console.error('Silakan ganti password PostgreSQL Anda terlebih dulu atau jalankan ulang script ini.');
                rl.close();
                process.exit(1);
            }
            await client.end().catch(() => { });
        }
    }

    if (connected) {
        rl.close();
        process.exit(0);
    }
}

main().catch(err => {
    console.error('Fatal Error:', err);
    rl.close();
    process.exit(1);
});
