const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env'), override: true });
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'cbt_tka',
  password: process.env.DB_PASSWORD || 'postgres',
  port: process.env.DB_PORT || 5432,
});

const initializeDB = async () => {
  const client = await pool.connect();
  try {
    console.log('🔄 Initializing database schema...');

    // Create Config Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS config (
        key VARCHAR(100) PRIMARY KEY,
        value TEXT NOT NULL
      );
    `);

    // Create Users Table (Admin/Guru)
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        username VARCHAR(50) PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        role VARCHAR(20) DEFAULT 'GURU'
      );
    `);

    // Create Students Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS students (
        username VARCHAR(50) PRIMARY KEY,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        class_id VARCHAR(50) NOT NULL
      );
    `);

    // Create Exams Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS exams (
        id VARCHAR(100) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        subject VARCHAR(100),
        class_grade VARCHAR(50),
        date VARCHAR(50),
        start_time VARCHAR(50),
        end_time VARCHAR(50),
        duration_minutes INTEGER,
        token VARCHAR(50) NOT NULL,
        status VARCHAR(20) DEFAULT 'DRAFT',
        questions JSONB,
        are_results_published BOOLEAN DEFAULT FALSE,
        randomize_questions BOOLEAN DEFAULT FALSE,
        randomize_options BOOLEAN DEFAULT FALSE
      );
    `);

    // Create Attempts Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS attempts (
        id SERIAL PRIMARY KEY,
        exam_id VARCHAR(100) REFERENCES exams(id) ON DELETE CASCADE,
        exam_title VARCHAR(255),
        student_name VARCHAR(100) NOT NULL,
        answers JSONB,
        score NUMERIC(5,2),
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        started_at TIMESTAMP,
        violation_count INTEGER DEFAULT 0,
        UNIQUE(exam_id, student_name)
      );
    `);

    // Create Live Progress Table (Memory mapping style in Postgres)
    await client.query(`
      CREATE TABLE IF NOT EXISTS live_progress (
        id SERIAL PRIMARY KEY,
        exam_id VARCHAR(100) REFERENCES exams(id) ON DELETE CASCADE,
        student_name VARCHAR(100) NOT NULL,
        answered_count INTEGER DEFAULT 0,
        total_questions INTEGER DEFAULT 0,
        status VARCHAR(50) DEFAULT 'WORKING',
        violation_count INTEGER DEFAULT 0,
        started_at TIMESTAMP,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(exam_id, student_name)
      );
    `);

    // Question Bank
    await client.query(`
        CREATE TABLE IF NOT EXISTS question_bank (
            id VARCHAR(100) PRIMARY KEY,
            text TEXT,
            type VARCHAR(50),
            subject VARCHAR(100),
            difficulty VARCHAR(20) DEFAULT 'Sedang',
            tags VARCHAR(500),
            image_url TEXT,
            passage TEXT,
            options JSONB,
            matching_pairs JSONB,
            statements JSONB,
            sequence_items JSONB,
            correct_sequence JSONB,
            classification_items JSONB,
            categories JSONB,
            classification_mapping JSONB,
            correct_key TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by VARCHAR(100),
            usage_count INTEGER DEFAULT 0,
            last_used_at TIMESTAMP,
            difficulty_index NUMERIC(5,2),
            discrimination_index NUMERIC(5,2),
            quality_status VARCHAR(50),
            last_analyzed TIMESTAMP
        );
    `);

    // --- MIGRATION: Update existing columns to TEXT if they were VARCHAR ---
    try {
      await client.query(`ALTER TABLE question_bank ALTER COLUMN image_url TYPE TEXT;`);
      await client.query(`ALTER TABLE question_bank ALTER COLUMN correct_key TYPE TEXT;`);
      console.log('✅ Migration: question_bank columns updated to TEXT');
    } catch (migErr) {
      // Ignore
    }

    // Migration: Add student_class to attempts
    try {
      await client.query(`ALTER TABLE attempts ADD COLUMN IF NOT EXISTS student_class VARCHAR(50);`);
      console.log('✅ Migration: student_class column added to attempts');
    } catch (migErr) {
      // Ignore
    }

    // Migration: Add started_at to attempts and live_progress
    try {
      await client.query(`ALTER TABLE attempts ADD COLUMN IF NOT EXISTS started_at TIMESTAMP;`);
      await client.query(`ALTER TABLE live_progress ADD COLUMN IF NOT EXISTS started_at TIMESTAMP;`);
      console.log('✅ Migration: started_at columns added');
    } catch (migErr) {
      // Ignore
    }

    // Migration: Add access_level to users
    try {
      await client.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS access_level VARCHAR(20) DEFAULT 'ADMIN';`);
      console.log('✅ Migration: access_level column added to users');
    } catch (migErr) {
      // Ignore
    }

    // Insert Default admin & student if users empty
    const userRes = await client.query('SELECT count(*) FROM users');
    if (parseInt(userRes.rows[0].count) === 0) {
      const hashedAdminPw = await bcrypt.hash('admin123', 10);
      await client.query(`
        INSERT INTO users (username, password, name, role, access_level) 
        VALUES ('admin', $1, 'Pak Guru', 'GURU', 'ADMIN')
      `, [hashedAdminPw]);
      console.log('✅ Default admin created');
    } else {
      // MIGRASI: Hash password yang masih plain text di table users
      const allUsers = await client.query('SELECT username, password FROM users');
      for (const user of allUsers.rows) {
        if (!user.password.startsWith('$2a$') && !user.password.startsWith('$2b$')) {
          console.log(`🔐 Migrasi: Hashing password untuk user [${user.username}]...`);
          const hashed = await bcrypt.hash(user.password, 10);
          await client.query('UPDATE users SET password = $1 WHERE username = $2', [hashed, user.username]);
        }
      }
    }

    const studentRes = await client.query('SELECT count(*) FROM students');
    if (parseInt(studentRes.rows[0].count) === 0) {
      const hashedStudentPw = await bcrypt.hash('siswa123', 10);
      await client.query(`
        INSERT INTO students (username, password, name, class_id) 
        VALUES ('siswa1', $1, 'Putra Panji Prasetiyo', 'VI A')
      `, [hashedStudentPw]);
      console.log('✅ Default student created');
    } else {
      // MIGRASI: Hash password yang masih plain text di table students
      const allStudents = await client.query('SELECT username, password FROM students');
      for (const student of allStudents.rows) {
        if (!student.password.startsWith('$2a$') && !student.password.startsWith('$2b$')) {
          console.log(`🔐 Migrasi: Hashing password untuk siswa [${student.username}]...`);
          const hashed = await bcrypt.hash(student.password, 10);
          await client.query('UPDATE students SET password = $1 WHERE username = $2', [hashed, student.username]);
        }
      }
    }

    // Default Config
    const configRes = await client.query('SELECT count(*) FROM config');
    if (parseInt(configRes.rows[0].count) === 0) {
      await client.query(`
              INSERT INTO config (key, value) VALUES 
              ('appName', 'EXAMPOINT'),
              ('schoolName', ''),
              ('logo', ''),
              ('maintenanceMode', 'false')
          `);
      console.log('✅ Default config created');
    } else {
      // Migration: Ensure new keys exist
      const keysRes = await client.query('SELECT key FROM config');
      const existingKeys = keysRes.rows.map(r => r.key);

      if (!existingKeys.includes('logo')) {
        await client.query("INSERT INTO config (key, value) VALUES ('logo', '')");
        console.log('✅ Migration: logo key added to config');
      }
      if (!existingKeys.includes('maintenanceMode')) {
        await client.query("INSERT INTO config (key, value) VALUES ('maintenanceMode', 'false')");
        console.log('✅ Migration: maintenanceMode key added to config');
      }
    }

    console.log('✅ Database schema initialized successfully');
  } catch (error) {
    console.error('❌ Error initializing database:', error);
  } finally {
    client.release();
  }
};

module.exports = {
  query: (text, params) => pool.query(text, params),
  initializeDB,
  pool
};
