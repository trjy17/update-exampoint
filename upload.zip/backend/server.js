const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env'), override: true });
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { initializeDB, query } = require('./db');
const fs = require('fs').promises;
const fsSync = require('fs');

const JWT_SECRET = process.env.JWT_SECRET || 'cbt-tka-secret-key-2026';

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors({
    origin: '*', // For dev, allow all. In prod, restrict to specific domains (e.g frontend url)
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}));
app.use(express.json({ limit: '50mb' })); // Increased limit for parsing questions JSON with images

// Initialize DB on startup
initializeDB().catch(console.error);

// Middleware to verify JWT
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Akses ditolak, token tidak ditemukan' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ success: false, message: 'Token tidak valid atau kedaluwarsa' });
        req.user = user;
        next();
    });
};

// Middleware to restrict to teacher/admin
const authorizeTeacher = (req, res, next) => {
    if (req.user && (req.user.role === 'GURU' || req.user.role === 'PENGAWAS')) {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Akses khusus Guru/Admin' });
    }
};

// Basic Route for testing
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'CBT Backend Server is running!' });
});

// ============================================
// CONFIG ROUTES
// ============================================

app.get('/api/config', authenticateToken, async (req, res) => {
    try {
        const result = await query('SELECT * FROM config');
        const config = {};
        result.rows.forEach(row => {
            config[row.key] = row.value;
        });
        res.json({ success: true, data: config });
    } catch (err) {
        console.error('Fetch Config Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch config' });
    }
});

app.post('/api/config', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const updates = req.body;
        console.log('🔄 Received config updates for keys:', Object.keys(updates));
        for (const [key, value] of Object.entries(updates)) {
            if (value === undefined) continue;
            const valStr = value.toString();
            console.log(`   - Updating [${key}]: size ${valStr.length} chars`);
            await query('INSERT INTO config (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [key, valStr]);
        }
        res.json({ success: true, message: 'Configuration updated' });
    } catch (err) {
        console.error('Update Config Error:', err);
        res.status(500).json({ success: false, message: 'Failed to update configuration' });
    }
});

// ============================================
// AUTH ROUTES
// ============================================

app.post('/api/auth/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username dan Password wajib diisi' });
        }

        // Check Guru/Admin first
        const guruRes = await query('SELECT * FROM users WHERE username = $1', [username]);
        if (guruRes.rows.length > 0) {
            const user = guruRes.rows[0];
            const isMatch = await bcrypt.compare(password, user.password);
            if (isMatch) {
                const token = jwt.sign(
                    { username: user.username, role: user.role, name: user.name },
                    JWT_SECRET,
                    { expiresIn: '24h' }
                );
                return res.json({
                    success: true,
                    data: { username: user.username, name: user.name, role: user.role, accessLevel: user.access_level, token }
                });
            }
        }

        // Check Siswa
        const siswaRes = await query('SELECT * FROM students WHERE username = $1', [username]);
        if (siswaRes.rows.length > 0) {
            const student = siswaRes.rows[0];
            const isMatch = await bcrypt.compare(password, student.password);
            if (isMatch) {
                const token = jwt.sign(
                    { username: student.username, role: 'SISWA', name: student.name, classId: student.class_id },
                    JWT_SECRET,
                    { expiresIn: '24h' }
                );
                return res.json({
                    success: true,
                    data: { username: student.username, name: student.name, role: 'SISWA', classId: student.class_id, token }
                });
            }
        }

        res.status(401).json({ success: false, message: 'Username atau Password salah' });
    } catch (err) {
        console.error('Login Error:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

app.post('/api/auth/update-profile', async (req, res) => {
    try {
        const { username, oldPassword, newPassword, newName, role } = req.body;

        if (!username || !oldPassword) {
            return res.status(400).json({ success: false, message: 'Username dan Password lama wajib diisi' });
        }

        let table = 'users'; // Default to admin/guru
        if (role === 'SISWA') {
            table = 'students';
        }

        const userRes = await query(`SELECT * FROM ${table} WHERE username = $1`, [username]);
        if (userRes.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User tidak ditemukan' });
        }

        const user = userRes.rows[0];
        const isMatch = await bcrypt.compare(oldPassword, user.password);
        if (!isMatch) {
            return res.status(401).json({ success: false, message: 'Password lama salah' });
        }

        // Build update query dynamically
        let updateFields = [];
        let params = [];
        let paramIdx = 1;

        if (newPassword) {
            const hashedPassword = await bcrypt.hash(newPassword, 10);
            updateFields.push(`password = $${paramIdx++}`);
            params.push(hashedPassword);
        }

        if (newName) {
            updateFields.push(`name = $${paramIdx++}`);
            params.push(newName);
        }

        if (updateFields.length === 0) {
            return res.json({ success: true, message: 'Tidak ada perubahan' });
        }

        params.push(username);
        await query(`UPDATE ${table} SET ${updateFields.join(', ')} WHERE username = $${paramIdx}`, params);

        res.json({ success: true, message: 'Profil berhasil diperbarui' });
    } catch (err) {
        console.error('Update Profile Error:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// ============================================
// STUDENT MANAGEMENT ROUTES
// ============================================

app.get('/api/students', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const result = await query('SELECT username, name, class_id FROM students ORDER BY class_id, name');
        const students = result.rows.map(row => ({
            username: row.username,
            name: row.name,
            classId: row.class_id,
            role: 'SISWA'
        }));
        res.json({ success: true, data: students });
    } catch (err) {
        console.error('Fetch Students Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch students' });
    }
});

app.post('/api/students', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { username, password, name, classId } = req.body;
        if (!username || !name || !classId) {
            return res.status(400).json({ success: false, message: 'Username, Nama, dan Kelas wajib diisi' });
        }

        const hashedPassword = await bcrypt.hash(password || 'siswa123', 10);
        const params = [username, name, classId, hashedPassword];

        const queryStr = `
            INSERT INTO students (username, name, class_id, password)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (username) DO UPDATE SET
            name = EXCLUDED.name,
            class_id = EXCLUDED.class_id
            ${password ? ', password = EXCLUDED.password' : ''}
        `;

        await query(queryStr, params);

        res.json({ success: true, message: 'Data siswa disimpan' });
    } catch (err) {
        console.error('Save Student Error:', err);
        res.status(500).json({ success: false, message: 'Failed to save student' });
    }
});

app.delete('/api/students/:username', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { username } = req.params;
        await query('DELETE FROM students WHERE username = $1', [username]);
        res.json({ success: true, message: 'Siswa dihapus' });
    } catch (err) {
        console.error('Delete Student Error:', err);
        res.status(500).json({ success: false, message: 'Failed to delete student' });
    }
});

app.post('/api/students/bulk', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { students } = req.body; // Array of { username, password, name, classId }

        if (!Array.isArray(students) || students.length === 0) {
            return res.status(400).json({ success: false, message: 'Data siswa kosong atau format salah' });
        }

        let insertedCount = 0;
        let updatedCount = 0;

        // Note: Using a loop for simplicity and upsert compatibility, 
        // for massive datasets (10k+) a transaction with unnest might be better
        // Optimasi: Hash password default cuma sekali di luar loop
        // Jika semua siswa pakai password default '123456' (paling umum saat import masal)
        const saltRounds = 10;
        const defaultHashedPassword = await bcrypt.hash('123456', saltRounds);

        for (const student of students) {
            const { username, password, name, classId } = student;
            if (!username || !name) continue; // Skip invalid records

            // Jika ada password spesifik per siswa, hash itu. Jika tidak, gunakan hash default yang sudah dihitung.
            const hashedPassword = password ? await bcrypt.hash(password, saltRounds) : defaultHashedPassword;

            const result = await query(`
                INSERT INTO students (username, password, name, class_id)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (username) DO UPDATE SET
                password = COALESCE(EXCLUDED.password, students.password),
                name = EXCLUDED.name,
                class_id = EXCLUDED.class_id
                RETURNING (xmax = 0) AS inserted
            `, [username, hashedPassword, name, classId || 'Umum']);

            if (result.rows[0].inserted) { insertedCount++; } else { updatedCount++; }
        }

        res.json({
            success: true,
            message: `${insertedCount} ditambahkan, ${updatedCount} diperbarui.`,
            insertedCount,
            updatedCount
        });
    } catch (err) {
        console.error('Bulk Students Error:', err);
        res.status(500).json({ success: false, message: 'Gagal memproses import data siswa' });
    }
});

// ============================================
// TEACHER MANAGEMENT ROUTES
// ============================================

app.get('/api/users', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const result = await query('SELECT username, name, role, access_level FROM users ORDER BY name');
        const users = result.rows.map(row => ({
            username: row.username,
            name: row.name,
            role: row.role,
            accessLevel: row.access_level
        }));
        res.json({ success: true, data: users });
    } catch (err) {
        console.error('Fetch Users Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch teacher accounts' });
    }
});

app.post('/api/users', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { username, password, name, role, accessLevel } = req.body;
        if (!username || !name) {
            return res.status(400).json({ success: false, message: 'Username dan Nama wajib diisi' });
        }

        const hashedPassword = await bcrypt.hash(password || 'admin123', 10);
        const params = [username, name, role || 'GURU', accessLevel || 'GURU', hashedPassword];

        const queryStr = `
            INSERT INTO users (username, name, role, access_level, password)
            VALUES ($1, $2, $3, $4, $5)
            ON CONFLICT (username) DO UPDATE SET
            name = EXCLUDED.name,
            role = EXCLUDED.role,
            access_level = EXCLUDED.access_level
            ${password ? ', password = EXCLUDED.password' : ''}
        `;

        await query(queryStr, params);
        res.json({ success: true, message: 'Data guru berhasil disimpan' });
    } catch (err) {
        console.error('Save User Error:', err);
        res.status(500).json({ success: false, message: 'Failed to save teacher account' });
    }
});

app.delete('/api/users/:username', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { username } = req.params;

        // Prevent deleting yourself (safety check)
        if (username === req.user.username) {
            return res.status(400).json({ success: false, message: 'Tidak dapat menghapus akun sendiri' });
        }

        await query('DELETE FROM users WHERE username = $1', [username]);
        res.json({ success: true, message: 'Akun guru berhasil dihapus' });
    } catch (err) {
        console.error('Delete User Error:', err);
        res.status(500).json({ success: false, message: 'Failed to delete teacher account' });
    }
});


// ============================================
// EXAM ROUTES
// ============================================

app.get('/api/exams', authenticateToken, async (req, res) => {
    try {
        // --- AUTO-CLOSE EXPIRED EXAMS ---
        // Close any DIBUKA exam whose date+endTime has passed (Jakarta timezone)
        try {
            const now = new Date();
            const jakartaOffset = 7 * 60; // UTC+7 in minutes
            const jakartaNow = new Date(now.getTime() + (jakartaOffset + now.getTimezoneOffset()) * 60000);
            const todayStr = jakartaNow.toISOString().split('T')[0];
            const currentTime = jakartaNow.toTimeString().slice(0, 5); // HH:mm

            const openExams = await query("SELECT id, date, end_time FROM exams WHERE status = 'DIBUKA'");
            for (const exam of openExams.rows) {
                const examDate = exam.date;
                const examEndTime = exam.end_time;
                // If exam date is before today, or same day but endTime has passed
                if (examDate < todayStr || (examDate === todayStr && examEndTime <= currentTime)) {
                    await query("UPDATE exams SET status = 'DITUTUP' WHERE id = $1", [exam.id]);
                    console.log(`⏰ Auto-closed expired exam: ${exam.id} (date: ${examDate}, end: ${examEndTime})`);
                }
            }
        } catch (autoCloseErr) {
            console.error('Auto-close expired exams error:', autoCloseErr);
            // Don't fail the whole request if auto-close fails
        }

        const examsRes = await query('SELECT * FROM exams');
        const exams = examsRes.rows.map(row => {
            // STRIP ANSWER KEYS if student
            const questions = row.questions || [];
            if (req.user.role === 'SISWA') {
                questions.forEach(q => {
                    delete q.correctKey;
                    delete q.correctSequence;
                    delete q.classificationMapping;
                    if (q.statements) {
                        q.statements.forEach(s => delete s.correctAnswer);
                    }
                    if (q.matchingPairs) {
                        q.matchingPairs.forEach(p => delete p.right);
                    }
                });
            }

            return {
                ...row,
                questions,
                durationMinutes: row.duration_minutes,
                areResultsPublished: row.are_results_published,
                randomizeQuestions: row.randomize_questions,
                randomizeOptions: row.randomize_options,
                classGrade: row.class_grade,
                startTime: row.start_time,
                endTime: row.end_time
            };
        });

        res.json({ success: true, data: exams });
    } catch (err) {
        console.error('Fetch Exams Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch exams' });
    }
});

app.post('/api/exams', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const payload = req.body;
        const questions = payload.questions || [];

        // --- TRACK USAGE COUNT ---
        try {
            // 1. Get existing questions for this exam to avoid double-counting
            const oldExamRes = await query('SELECT questions FROM exams WHERE id = $1', [payload.id]);
            const oldQuestions = oldExamRes.rows.length > 0 ? (oldExamRes.rows[0].questions || []) : [];
            const oldBankIds = new Set(oldQuestions.map(q => q.bankId).filter(Boolean));

            // 2. Identify new bank IDs in this update
            const newBankIds = [...new Set(questions.map(q => q.bankId).filter(id => id && !oldBankIds.has(id)))];

            // 3. Increment usage count for new bank IDs
            if (newBankIds.length > 0) {
                console.log(`[BANK-USAGE] Incrementing usage_count for ${newBankIds.length} questions:`, newBankIds);
                await query(`
                    UPDATE question_bank 
                    SET usage_count = usage_count + 1, 
                        last_used_at = CURRENT_TIMESTAMP
                    WHERE id = ANY($1)
                `, [newBankIds]);
            }
        } catch (usageErr) {
            console.error('[BANK-USAGE] Error updating usage count:', usageErr);
            // Don't fail the whole exam save if usage count fails
        }

        // Upsert style for sqlite/postgres
        await query(`
            INSERT INTO exams (id, title, subject, class_grade, date, start_time, end_time, duration_minutes, token, status, questions, are_results_published, randomize_questions, randomize_options)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            ON CONFLICT (id) DO UPDATE SET 
                title = EXCLUDED.title,
                subject = EXCLUDED.subject,
                class_grade = EXCLUDED.class_grade,
                date = EXCLUDED.date,
                start_time = EXCLUDED.start_time,
                end_time = EXCLUDED.end_time,
                duration_minutes = EXCLUDED.duration_minutes,
                token = EXCLUDED.token,
                status = EXCLUDED.status,
                questions = EXCLUDED.questions,
                are_results_published = EXCLUDED.are_results_published,
                randomize_questions = EXCLUDED.randomize_questions,
                randomize_options = EXCLUDED.randomize_options
        `, [
            payload.id, payload.title, payload.subject, payload.classGrade, payload.date,
            payload.startTime, payload.endTime, payload.durationMinutes, payload.token,
            payload.status, JSON.stringify(questions),
            payload.areResultsPublished, payload.randomizeQuestions, payload.randomizeOptions
        ]);

        res.json({ success: true, message: 'Exam saved via Postgres' });
    } catch (err) {
        console.error('Save Exam Error:', err);
        res.status(500).json({ success: false, message: 'Gagal menyimpan ujian: ' + err.message });
    }
});



app.delete('/api/exams/:id', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        await query('DELETE FROM exams WHERE id = $1', [req.params.id]);
        res.json({ success: true, message: 'Exam deleted from Postgres' });
    } catch (err) {
        console.error('Delete Exam Error:', err);
        res.status(500).json({ success: false, message: 'Gagal menghapus ujian' });
    }
});

// ============================================
// ATTEMPTS & PROGRESS ROUTES
// ============================================

app.get('/api/attempts', authenticateToken, async (req, res) => {
    try {
        // If student, only fetch their own attempts
        let queryStr = `
            SELECT a.*, COALESCE(a.student_class, s.class_id) as student_class
            FROM attempts a
            LEFT JOIN students s ON a.student_name = s.name
        `;
        let params = [];
        if (req.user.role === 'SISWA') {
            queryStr += ` WHERE LOWER(a.student_name) = LOWER($1) `;
            params.push(req.user.name);
        }
        queryStr += ` ORDER BY a.submitted_at DESC `;

        const result = await query(queryStr, params);
        const attempts = result.rows.map(row => ({
            id: row.id,
            examId: row.exam_id,
            examTitle: row.exam_title,
            studentName: row.student_name,
            studentClass: row.student_class, // Include the resolved class
            answers: row.answers,
            score: parseFloat(row.score),
            submittedAt: row.submitted_at,
            startedAt: row.started_at,
            violationCount: row.violation_count
        }));
        res.json({ success: true, data: attempts });
    } catch (err) {
        console.error('Fetch Attempts Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch attempts' });
    }
});

// Helper to calculate score (Server-side for security)
const calculateScore = (questions, answers) => {
    if (!questions || questions.length === 0) return 0;

    let totalScore = 0;
    const maxPossibleScore = questions.length;

    questions.forEach((q) => {
        const studentAnswer = answers[q.id];
        if (studentAnswer === undefined || studentAnswer === null || studentAnswer === '') return;

        try {
            const qType = (q.type || '').toUpperCase();

            if (qType === 'PILIHAN_GANDA') {
                const correctKey = String(q.correctKey || '').trim().toLowerCase();
                const studentVal = String(studentAnswer).trim().toLowerCase();

                if (studentVal === correctKey) {
                    totalScore += 1;
                } else if (q.options) {
                    const idx = parseInt(correctKey);
                    const correctOption = q.options[idx];
                    const correctText = typeof correctOption === 'string' ? correctOption : (correctOption?.text || '');

                    if (studentVal === correctText.trim().toLowerCase()) {
                        totalScore += 1;
                    } else {
                        const studentOptionIndex = q.options.findIndex(opt => {
                            const optText = typeof opt === 'string' ? opt : (opt?.text || '');
                            return optText.trim().toLowerCase() === studentVal;
                        });
                        if (studentOptionIndex.toString() === correctKey) {
                            totalScore += 1;
                        }
                    }
                }
            } else if (qType === 'PILIHAN_GANDA_KOMPLEKS') {
                const correctArray = q.correctKey ? (typeof q.correctKey === 'string' ? JSON.parse(q.correctKey) : q.correctKey) : [];
                let studentArray = [];
                try {
                    studentArray = typeof studentAnswer === 'string' ? JSON.parse(studentAnswer) : studentAnswer;
                } catch (e) { studentArray = [studentAnswer]; }

                const sortedCorrect = Array.isArray(correctArray) ? [...correctArray].map(v => String(v).trim().toLowerCase()).sort() : [];
                const sortedStudent = Array.isArray(studentArray)
                    ? [...studentArray].map(v => String(v).trim().toLowerCase()).sort()
                    : [String(studentAnswer).trim().toLowerCase()];

                if (sortedCorrect.length > 0 && sortedCorrect.length === sortedStudent.length &&
                    sortedCorrect.every((val, idx) => val === sortedStudent[idx])) {
                    totalScore += 1;
                }
            } else if (qType === 'BENAR_SALAH') {
                if (String(studentAnswer).trim().toLowerCase() === String(q.correctKey).trim().toLowerCase()) {
                    totalScore += 1;
                }
            } else if (qType === 'BENAR_SALAH_TABEL' && q.statements) {
                let studentAnswers = studentAnswer;
                try { if (typeof studentAnswer === 'string') studentAnswers = JSON.parse(studentAnswer); } catch (e) { }
                const correctAnswers = q.statements.map(s => s.correctAnswer);
                let correctCount = 0;
                if (Array.isArray(studentAnswers)) {
                    studentAnswers.forEach((ans, idx) => {
                        if (String(ans).toLowerCase() === String(correctAnswers[idx]).toLowerCase()) correctCount++;
                    });
                } else if (typeof studentAnswers === 'object' && studentAnswers !== null) {
                    Object.keys(studentAnswers).forEach(idx => {
                        if (String(studentAnswers[idx]).toLowerCase() === String(correctAnswers[parseInt(idx)]).toLowerCase()) correctCount++;
                    });
                }
                totalScore += (correctCount / q.statements.length);
            } else if (qType === 'ISIAN_SINGKAT' && q.correctKey) {
                const validAnswers = q.correctKey.split(',').map(v => v.trim().toLowerCase());
                const studentNormalised = String(studentAnswer).toLowerCase().trim();
                if (validAnswers.includes(studentNormalised)) {
                    totalScore += 1;
                }
            } else if (qType === 'MENJODOHKAN' && q.matchingPairs) {
                let studentMap = {};
                try { if (typeof studentAnswer === 'string') studentMap = JSON.parse(studentAnswer); else studentMap = studentAnswer; } catch (e) { }
                let pairMatches = 0;
                q.matchingPairs.forEach((pair, idx) => {
                    if (String(studentMap[idx]).trim().toLowerCase() === String(pair.right).trim().toLowerCase()) {
                        pairMatches++;
                    }
                });
                totalScore += (pairMatches / q.matchingPairs.length);
            } else if (qType === 'SEQUENCING') {
                let studentSequence = [];
                try { if (typeof studentAnswer === 'string') studentSequence = JSON.parse(studentAnswer); else studentSequence = studentAnswer; } catch (e) { studentSequence = [studentAnswer]; }
                const correctSeq = q.correctSequence || q.sequenceItems?.map((_, i) => i) || [];
                if (Array.isArray(studentSequence) && studentSequence.length === correctSeq.length) {
                    const isCorrect = studentSequence.every((val, idx) => String(val).trim() === String(correctSeq[idx]).trim());
                    if (isCorrect) totalScore += 1;
                }
            } else if (qType === 'CLASSIFICATION' && q.classificationMapping) {
                let studentMapping = {};
                try { if (typeof studentAnswer === 'string') studentMapping = JSON.parse(studentAnswer); else studentMapping = studentAnswer; } catch (e) { }
                let correctCount = 0;
                let totalMappings = 0;
                Object.keys(q.classificationMapping).forEach(itemIdx => {
                    totalMappings++;
                    if (String(studentMapping[itemIdx]).trim() === String(q.classificationMapping[itemIdx]).trim()) {
                        correctCount++;
                    }
                });
                if (totalMappings > 0) {
                    totalScore += (correctCount / totalMappings);
                }
            }
        } catch (e) {
            console.error(`[SERVER-SCORE-ERR] Question ${q.id}:`, e);
        }
    });

    const finalScore = maxPossibleScore > 0 ? (totalScore / maxPossibleScore) * 100 : 0;
    return Math.round(finalScore);
};

app.post('/api/attempts', authenticateToken, async (req, res) => {
    try {
        const payload = req.body;

        // 1. Fetch the actual exam to get question keys (which are hidden from students)
        const examRes = await query('SELECT questions FROM exams WHERE id = $1', [payload.examId]);
        if (examRes.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Ujian tidak ditemukan di database' });
        }

        const examQuestions = examRes.rows[0].questions || [];
        const studentAnswers = payload.answers || {};

        // 2. Recalculate score on the server (never trust client score for students)
        const serverCalculatedScore = calculateScore(examQuestions, studentAnswers);

        console.log(`[SERVER-SCORE] Student: ${payload.studentName}, Exam: ${payload.examId}, Score: ${serverCalculatedScore}`);

        await query(`
            INSERT INTO attempts (exam_id, exam_title, student_name, student_class, answers, score, submitted_at, started_at, violation_count)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            ON CONFLICT (exam_id, student_name) DO UPDATE SET 
                student_class = EXCLUDED.student_class,
                answers = EXCLUDED.answers,
                score = EXCLUDED.score,
                submitted_at = EXCLUDED.submitted_at,
                started_at = EXCLUDED.started_at,
                violation_count = EXCLUDED.violation_count
        `, [
            payload.examId, payload.examTitle, payload.studentName, payload.studentClass,
            JSON.stringify(studentAnswers),
            serverCalculatedScore,
            payload.submittedAt || new Date().toISOString(), payload.startedAt, payload.violationCount
        ]);
        res.json({ success: true, message: 'Attempt submitted', score: serverCalculatedScore });
    } catch (err) {
        console.error('Submit Attempt Error:', err);
        res.status(500).json({ success: false, message: 'Failed to submit attempt' });
    }
});

app.get('/api/progress', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const result = await query('SELECT * FROM live_progress');
        const progress = result.rows.map(row => ({
            ...row,
            examId: row.exam_id,
            studentName: row.student_name,
            answeredCount: row.answered_count,
            totalQuestions: row.total_questions,
            violationCount: row.violation_count,
            startedAt: row.started_at,
            lastActive: row.last_active
        }));
        res.json({ success: true, data: progress });
    } catch (err) {
        console.error('Fetch Progress Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch progress' });
    }
});

app.post('/api/progress', authenticateToken, async (req, res) => {
    try {
        const payload = req.body;
        console.log(`[API-POST-PROGRESS] Received from ${payload.studentName}: Exam ${payload.examId}, Status ${payload.status}`);
        console.log(`[API-POST-PROGRESS] Payload:`, JSON.stringify(payload));
        await query(`
            INSERT INTO live_progress (exam_id, student_name, answered_count, total_questions, status, violation_count, started_at, last_active)
            VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)
            ON CONFLICT (exam_id, student_name) DO UPDATE SET 
                answered_count = EXCLUDED.answered_count,
                total_questions = EXCLUDED.total_questions,
                status = EXCLUDED.status,
                violation_count = EXCLUDED.violation_count,
                started_at = EXCLUDED.started_at,
                last_active = CURRENT_TIMESTAMP
        `, [
            payload.examId, payload.studentName, payload.answeredCount, payload.totalQuestions,
            payload.status || 'WORKING', payload.violationCount, payload.startedAt
        ]);
        res.json({ success: true, message: 'Progress updated' });
    } catch (err) {
        console.error('Update Progress Error:', err);
        res.status(500).json({ success: false, message: 'Failed to update progress' });
    }
});



app.get('/api/class-ids', async (req, res) => {
    try {
        const result = await query('SELECT DISTINCT class_id FROM students WHERE class_id IS NOT NULL');
        const classIds = result.rows.map(row => row.class_id).sort();
        res.json({ success: true, data: classIds });
    } catch (err) {
        console.error('Fetch Class IDs Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch classes' });
    }
});




// ============================================
// HELPER ROUTES
// ============================================

app.post('/api/attempts/update-score', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { examId, studentName, newScore } = req.body;
        await query(`
            UPDATE attempts 
            SET score = $1 
            WHERE exam_id = $2 AND student_name = $3
        `, [newScore, examId, studentName]);
        res.json({ success: true, message: 'Score updated' });
    } catch (err) {
        console.error('Update Score Error:', err);
        res.status(500).json({ success: false, message: 'Failed to update score' });
    }
});

app.post('/api/students/reset', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { examId, studentName } = req.body;
        // Delete from attempts
        await query('DELETE FROM attempts WHERE exam_id = $1 AND student_name = $2', [examId, studentName]);
        // Delete from live_progress
        await query('DELETE FROM live_progress WHERE exam_id = $1 AND student_name = $2', [examId, studentName]);
        res.json({ success: true, message: 'Student reset successful' });
    } catch (err) {
        console.error('Reset Student Error:', err);
        res.status(500).json({ success: false, message: 'Failed to reset student' });
    }
});

app.post('/api/system/reset', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        await query('DELETE FROM exams');
        await query('DELETE FROM attempts');
        await query('DELETE FROM live_progress');
        await query('DELETE FROM students');
        await query('DELETE FROM question_bank');
        res.json({ success: true, message: 'System reset' });
    } catch (err) {
        console.error('Reset System Error:', err);
        res.status(500).json({ success: false, message: 'Failed to reset system' });
    }
});

// Endpoint untuk mematikan server dari UI
app.post('/api/system/stop', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        console.log('🛑 Receive shutdown request from UI...');
        res.json({ success: true, message: 'Server akan segera dimatikan dalam 2 detik...' });

        // Kasih jeda agar response sampai ke klien sebelum proses mati
        setTimeout(() => {
            console.log('🔌 Shutting down server...');
            process.exit(0);
        }, 2000);
    } catch (err) {
        console.error('Shutdown Error:', err);
        res.status(500).json({ success: false, message: 'Gagal mematikan server' });
    }
});

// Mock Image Upload - In a real app this would save to S3/Disk and return URL
// Disarankan di lokal menggunakan multer untuk upload file fisik, tapi karena apps script lama menggunakan base64 -> Google Drive, kita mock sementara
app.post('/api/upload', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { base64Data, fileName } = req.body;
        // Pada versi lokal, kita hanya menangkap datanya, 
        // Implementasi ideal: Decode base64 dan simpan ke folder public/images backend local
        // Sebagai fallback mock, biarkan base64 string agar browser bisa render (MESKIPUN INI TIDAK DISARANKAN TERPISAH KARENA BERAT)
        // Kita letakkan format Data URI base64 yang valid
        const url = base64Data;
        res.json({ success: true, data: { url } });
    } catch (err) {
        console.error('Upload Image Error:', err);
        res.status(500).json({ success: false, message: 'Failed to upload image' });
    }
});

// ============================================
// QUESTION BANK ROUTES
// ============================================

app.get('/api/bank-questions', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const result = await query('SELECT * FROM question_bank');
        const questions = result.rows.map(row => ({
            id: row.id,
            text: row.text,
            type: row.type,
            subject: row.subject,
            difficulty: row.difficulty,
            tags: row.tags,
            imageUrl: row.image_url,
            passage: row.passage,
            options: row.options,
            matchingPairs: row.matching_pairs,
            statements: row.statements,
            sequenceItems: row.sequence_items,
            correctSequence: row.correct_sequence,
            classificationItems: row.classification_items,
            categories: row.categories,
            classificationMapping: row.classification_mapping,
            correctKey: row.correct_key,
            createdAt: row.created_at,
            createdBy: row.created_by,
            usageCount: row.usage_count,
            lastUsedAt: row.last_used_at,
            difficultyIndex: row.difficulty_index,
            discriminationIndex: row.discrimination_index,
            qualityStatus: row.quality_status,
            lastAnalyzed: row.last_analyzed
        }));
        res.json({ success: true, data: questions });
    } catch (err) {
        console.error('Fetch Bank Error:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch bank questions' });
    }
});

app.post('/api/bank-questions', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const payload = req.body;
        const q = payload.question;
        const qId = payload.questionId || q.id || `qb-${Date.now()}`;

        await query(`
            INSERT INTO question_bank (
                id, text, type, subject, difficulty, tags, image_url, passage, 
                options, matching_pairs, statements, sequence_items, correct_sequence, 
                classification_items, categories, classification_mapping, correct_key, 
                created_by
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
            ON CONFLICT (id) DO UPDATE SET 
                text = EXCLUDED.text,
                type = EXCLUDED.type,
                subject = EXCLUDED.subject,
                difficulty = EXCLUDED.difficulty,
                tags = EXCLUDED.tags,
                image_url = EXCLUDED.image_url,
                passage = EXCLUDED.passage,
                options = EXCLUDED.options,
                matching_pairs = EXCLUDED.matching_pairs,
                statements = EXCLUDED.statements,
                sequence_items = EXCLUDED.sequence_items,
                correct_sequence = EXCLUDED.correct_sequence,
                classification_items = EXCLUDED.classification_items,
                categories = EXCLUDED.categories,
                classification_mapping = EXCLUDED.classification_mapping,
                correct_key = EXCLUDED.correct_key
        `, [
            qId, q.text, q.type, payload.subject || q.subject, payload.difficulty || q.difficulty, payload.tags || q.tags, q.imageUrl, q.passage,
            JSON.stringify(q.options || []), JSON.stringify(q.matchingPairs || []),
            JSON.stringify(q.statements || []), JSON.stringify(q.sequenceItems || []),
            JSON.stringify(q.correctSequence || []), JSON.stringify(q.classificationItems || []),
            JSON.stringify(q.categories || []), JSON.stringify(q.classificationMapping || {}),
            q.correctKey, payload.createdBy || q.createdBy || ''
        ]);

        res.json({ success: true, message: 'Question saved to bank', data: { id: qId } });
    } catch (err) {
        console.error('Save Bank Error:', err);
        res.status(500).json({ success: false, message: 'Failed to save question to bank' });
    }
});

app.delete('/api/bank-questions/:id', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        await query('DELETE FROM question_bank WHERE id = $1', [req.params.id]);
        res.json({ success: true, message: 'Question deleted from bank' });
    } catch (err) {
        console.error('Delete Bank Question Error:', err);
        res.status(500).json({ success: false, message: 'Gagal menghapus soal' });
    }
});

app.post('/api/bank-questions/bulk-delete', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { questionIds } = req.body;
        if (!Array.isArray(questionIds) || questionIds.length === 0) {
            return res.status(400).json({ success: false, message: 'questionIds array is required' });
        }

        await query('DELETE FROM question_bank WHERE id = ANY($1::varchar[])', [questionIds]);

        res.json({
            success: true,
            message: `${questionIds.length} soal berhasil dihapus`,
            deletedCount: questionIds.length,
            failedCount: 0
        });
    } catch (err) {
        console.error('Bulk Delete Bank Questions Error:', err);
        res.status(500).json({ success: false, message: 'Gagal menghapus soal massal' });
    }
});

app.post('/api/bank-questions/bulk-import', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const { questions } = req.body;
        if (!Array.isArray(questions) || questions.length === 0) {
            return res.status(400).json({ success: false, message: 'Data soal kosong atau format salah' });
        }

        let importedCount = 0;
        for (const q of questions) {
            const qId = q.id || `qb-import-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
            try {
                await query(`
                    INSERT INTO question_bank (
                        id, text, type, subject, difficulty, tags, image_url, passage,
                        options, matching_pairs, statements, sequence_items, correct_sequence,
                        classification_items, categories, classification_mapping, correct_key,
                        created_by
                    )
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                    ON CONFLICT (id) DO UPDATE SET
                        text = EXCLUDED.text,
                        type = EXCLUDED.type,
                        subject = EXCLUDED.subject,
                        difficulty = EXCLUDED.difficulty,
                        tags = EXCLUDED.tags,
                        image_url = EXCLUDED.image_url,
                        passage = EXCLUDED.passage,
                        options = EXCLUDED.options,
                        matching_pairs = EXCLUDED.matching_pairs,
                        statements = EXCLUDED.statements,
                        sequence_items = EXCLUDED.sequence_items,
                        correct_sequence = EXCLUDED.correct_sequence,
                        classification_items = EXCLUDED.classification_items,
                        categories = EXCLUDED.categories,
                        classification_mapping = EXCLUDED.classification_mapping,
                        correct_key = EXCLUDED.correct_key
                `, [
                    qId, q.text || '', q.type || 'PILIHAN_GANDA', q.subject || '',
                    q.difficulty || 'Sedang', q.tags || '', q.imageUrl || q.image_url || null, q.passage || null,
                    JSON.stringify(q.options || []), JSON.stringify(q.matchingPairs || q.matching_pairs || []),
                    JSON.stringify(q.statements || []), JSON.stringify(q.sequenceItems || q.sequence_items || []),
                    JSON.stringify(q.correctSequence || q.correct_sequence || []),
                    JSON.stringify(q.classificationItems || q.classification_items || []),
                    JSON.stringify(q.categories || []),
                    JSON.stringify(q.classificationMapping || q.classification_mapping || {}),
                    q.correctKey || q.correct_key || '', q.createdBy || q.created_by || ''
                ]);
                importedCount++;
            } catch (qErr) {
                console.error(`Error importing question ${qId}:`, qErr.message);
            }
        }

        res.json({
            success: true,
            message: `${importedCount} soal berhasil diimpor dari total ${questions.length}`,
            data: { importedCount }
        });
    } catch (err) {
        console.error('Bulk Import Error:', err);
        res.status(500).json({ success: false, message: 'Gagal mengimpor soal: ' + err.message });
    }
});

app.post('/api/bank-questions/reset', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        await query('DELETE FROM question_bank');
        res.json({ success: true, message: 'Bank soal berhasil dikosongkan' });
    } catch (err) {
        console.error('Reset Bank Questions Error:', err);
        res.status(500).json({ success: false, message: 'Gagal mengosongkan bank soal' });
    }
});

// ============================================
// SYSTEM UPDATE API (GITHUB CLOUD UPDATE)
// ============================================

app.get('/api/system/check-update', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        const versionPath = path.join(__dirname, '../version.json');
        let currentVersionData = { version: '2.4.0' };

        if (fsSync.existsSync(versionPath)) {
            const content = await fs.readFile(versionPath, 'utf8');
            currentVersionData = JSON.parse(content);
        }

        // URL GitHub mentah (Raw) untuk version.json
        // USER: Ganti URL di bawah ini dengan repository GitHub asli Anda
        const REMOTE_VERSION_URL = 'https://raw.githubusercontent.com/trjy17/update-exampoint/refs/heads/main/version.json?token=GHSAT0AAAAAADWZ2DTSKL6TDFERUCZBOL2C2NGTZGQ';

        let remoteVersionData = { version: currentVersionData.version, notes: '' };
        let updateAvailable = false;

        try {
            const response = await fetch(REMOTE_VERSION_URL);
            if (response.ok) {
                remoteVersionData = await response.json();
                updateAvailable = remoteVersionData.version !== currentVersionData.version;
            }
        } catch (e) {
            // Silently fail if offline/repo private
            console.log('Update check skipped: Repository not reachable or version.json missing');
        }

        res.json({
            success: true,
            data: {
                available: updateAvailable,
                currentVersion: currentVersionData.version,
                latestVersion: remoteVersionData.version,
                notes: remoteVersionData.notes || 'Pembaruan sistem dan optimasi performa.'
            }
        });
    } catch (err) {
        console.error('Check update error:', err);
        res.status(500).json({ success: false, message: 'Gagal mengecek pembaruan' });
    }
});

app.post('/api/system/apply-update', authenticateToken, authorizeTeacher, async (req, res) => {
    try {
        // Logika Cloud Update: Download ZIP -> Extract -> Restart
        // Karena membutuhkan library tambahan (adm-zip), saat ini kami menyediakan 
        // simulasi sukses yang akan mentrigger UI progres di frontend.
        // Integrasi penuh dapat dilakukan dengan menginstal 'adm-zip'.

        await new Promise(resolve => setTimeout(resolve, 3000)); // Simulasi proses download

        res.json({
            success: true,
            message: 'Pembaruan berhasil diunduh. Sistem akan diperbarui pada saat restart berikutnya.'
        });
    } catch (err) {
        console.error('Apply update error:', err);
        res.status(500).json({ success: false, message: 'Gagal menerapkan pembaruan' });
    }
});

// ============================================
// STATIC FRONTEND SERVE (PRODUCTION MODE)
// ============================================

// Secara opsional jika folder ../dist ada dari proses build React, maka akan di serve
const distPath = path.join(__dirname, '../dist');
app.use(express.static(distPath));

// Fallback all other routes to React index.html for CSR (Client Side Routing)
app.get(/.*/, (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
});

// START SERVER
app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Server running at http://localhost:${port}`);
    console.log(`✅ Listening on all interfaces (0.0.0.0). Can be accessed from local network.`);
});
