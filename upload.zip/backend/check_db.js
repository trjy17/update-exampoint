const { Client } = require('pg');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '.env') });

async function checkDB() {
    const client = new Client({
        user: process.env.DB_USER || 'postgres',
        host: process.env.DB_HOST || 'localhost',
        database: process.env.DB_NAME || 'cbt_tka',
        password: process.env.DB_PASSWORD || 'postgres',
        port: process.env.DB_PORT || 5432,
    });

    try {
        await client.connect();
        console.log('--- LIVE PROGRESS ---');
        const progress = await client.query('SELECT * FROM live_progress');
        console.table(progress.rows);

        console.log('--- ATTEMPTS ---');
        const attempts = await client.query('SELECT * FROM attempts');
        console.table(attempts.rows);
    } catch (err) {
        console.error('Database Error:', err.message);
    } finally {
        await client.end();
    }
}

checkDB();
